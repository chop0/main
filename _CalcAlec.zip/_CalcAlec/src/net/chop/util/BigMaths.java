package net.chop.util;

/**
 * @author Alec Petridis
 */

public class BigMaths {
	  /**
	   * @author Alec Petridis
	   * @param n th root
	   * @param x number
	   * @return Find nth root of x
	   * 
	   * This function will return x's nth root. For example, <pre> nthroot(2, 4) </pre>
	   * will return the second or square root of 4, which is 2.
	   */
	
	  public static double nthroot(double n, double x) 
	    {
	        return nthroot(n, x, .0001);
	    }
	  
	    private static double nthroot(double n, double x, double p) // Can't remember how this works, but I remember how to do it
	    {
	        if(x < 0) 
	        {
	            System.err.println("Negative!");
	            return -1;
	        }
	        if(x == 0) 
	            return 0;
	        double x1 = x;
	        double x2 = x / n;  
	        while (Math.abs(x1 - x2) > p) 
	        {
	            x1 = x2;
	            x2 = ((n - 1.0) * x2 + x / Math.pow(x2, n - 1.0)) / n;
	        }
	        return x2;
	    }
	    
	    /**
	     * 
	     * @param number - The number to find secant of
	     * @return 1 divided by the cosine of <strong>number</strong>
	     */
	    public static double secant(double number) {
		return 1/Math.cos(number);
	    }
	    
	    /**
	     * 
	     * @param number - The number to find cosecant of
	     * @return 1 divided by the sine of <strong>number</strong>
	     */
	    public static double cosecant(double number) {
		return 1/Math.sin(number);
	    }
	    
	    /**
	     * 
	     * @param number - The number to find cotangent of
	     * @return 1 divided by the tangent of <strong>number</strong>
	     */
	    public static double cotangent(double number) {
		return 1/Math.tan(number);
	    }
}