/**
 * 
 */
package wzb;

/**
 * @author Wizbots
 *
 */
public class MyProgram {

    /**
     * 
     */
    public MyProgram() {
	super();
    }

    /**
     * @param args
     */
    public static void main(String[] args) {
	net.chop.nxt.main.Run.main(args);

    }

}
