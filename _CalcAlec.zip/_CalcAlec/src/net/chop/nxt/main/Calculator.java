package net.chop.nxt.main;

import java.util.HashMap;
import java.util.Map;

import wzb.Program;
import lejos.nxt.LCD;
import static net.chop.util.BigMaths.*;

/**
 * 
 * @author Alec Petridis
 *         <p>
 *         This class will run a calculator on the NXT.
 *         </p>
 */
public class Calculator extends Program {

    private Map<Integer, String> modes;
    int currentSymbol = 1;
    boolean skip = false;

    @SuppressWarnings("deprecation")
    /** Not sure why <pre> java.util.HashMap </pre> is deprecated */
    public Calculator() {

	modes = new HashMap<Integer, String>();
	modes.put(1, "+");
	modes.put(2, "-");
	modes.put(3, "*");
	modes.put(4, "/");
	modes.put(5, "absolute");
	modes.put(6, "^");
	modes.put(7, "root");
	modes.put(8, "dec to bin");
	modes.put(9, "dec to hex");
	
	
	modes.put(10, "tan");
	modes.put(11, "sin");
	modes.put(12, "cos");
	modes.put(13, "sec");
	modes.put(14, "csc");
	modes.put(15, "cot");

	new Thread(new Runnable() { // Using threads because multiple sequences
				    // are higher level, so likely slower
		    public void run() {
			while (true) {
			    if (isNXTButton(ESCAPE, DOWN).isTrue())
				lejos.nxt.NXT.shutDown();

			    wbPrint(modes.get(currentSymbol), 4, 6); // Print
								     // the mode
								     // near the
								     // middle
								     // of the
								     // screen

			    if (isNXTButton(RIGHT, DOWN).isTrue()) {
				if (currentSymbol < modes.size())
				    currentSymbol++;
				else
				    currentSymbol = 1;
			    } else if (isNXTButton(LEFT, DOWN).isTrue()) {
				if (currentSymbol > 1)
				    currentSymbol--;
				else
				    currentSymbol = modes.size();

			    }

			    wbWaitSeconds(0.3); // Avoid switch bounce
			}
		    }
		}).start();
    }

    void sequence1() {
	try { // For InterruptedException
	    String lastScreen = "";

	    while (true) {

		int first = 0; // The first and second inputs
		int second = 0;

		switch (currentSymbol) {
		case 1: // Addition

		    LCD.clear(); // Clear the screen
		    while (currentSymbol == 1) {

			if ((wbRead(PORT_A) / 100 < 10 && first > 9)
				|| (wbRead(PORT_A) / 100 > -1 && first < 0)
				|| (wbRead(PORT_B) / 100 < 10 && second > 9)
				|| (wbRead(PORT_B) / 100 > -1 && second < 0)) {
			    LCD.clear();
			}
			first = (int) wbRead(PORT_A) / 100;
			second = (int) wbRead(PORT_B) / 100;

			/*
			 * Only update if we need to
			 */
			if (!lastScreen.equals(first + " + " + second))
			    wbPrint(first + " + " + second, 1, 1);

			lastScreen = first + " + " + second;

			if (isNXTButton(ENTER, DOWN).isTrue()) {
			    LCD.clear();
			    wbPrint(String.valueOf(first + second), 1, 1); // If
									   // button
									   // is
									   // pressed,
									   // display
									   // answer
									   // until
									   // told
									   // to
									   // continue
			    Thread.sleep(500);
			    while (isNXTButton(ENTER, DOWN).isFalse())
				;

			    LCD.clear();

			    wbPrint(lastScreen, 1, 1);
			    Thread.sleep(500);
			}

		    }

		case 2: // Subtraction
		    LCD.clear();
		    while (currentSymbol == 2) {

			if ((wbRead(PORT_A) / 100 < 10 && first > 9)
				|| (wbRead(PORT_A) / 100 > -1 && first < 0)
				|| (wbRead(PORT_B) / 100 < 10 && second > 9)
				|| (wbRead(PORT_B) / 100 > -1 && second < 0)) {
			    LCD.clear();
			}

			first = (int) wbRead(PORT_A) / 100;
			second = (int) wbRead(PORT_B) / 100;

			if (!lastScreen.equals(first + " - " + second))
			    wbPrint(first + " - " + second, 1, 1);

			lastScreen = first + " - " + second;

			if (isNXTButton(ENTER, DOWN).isTrue()) {
			    LCD.clear();
			    wbPrint(String.valueOf(first - second), 1, 1);
			    Thread.sleep(500);
			    while (isNXTButton(ENTER, DOWN).isFalse())
				;

			    LCD.clear();

			    wbPrint(lastScreen, 1, 1);
			    Thread.sleep(500);
			    break;
			}

		    }
		    break;

		case 3: // Multiplication
		    LCD.clear();
		    while (currentSymbol == 3) {

			if ((wbRead(PORT_A) / 100 < 10 && first > 9)
				|| (wbRead(PORT_A) / 100 > -1 && first < 0)
				|| (wbRead(PORT_B) / 100 < 10 && second > 9)
				|| (wbRead(PORT_B) / 100 > -1 && second < 0)) {
			    LCD.clear();
			}
			first = (int) wbRead(PORT_A) / 100;
			second = (int) wbRead(PORT_B) / 100;

			if (!lastScreen.equals(first + " * " + second))
			    wbPrint(first + " * " + second, 1, 1);

			lastScreen = first + " * " + second;

			if (isNXTButton(ENTER, DOWN).isTrue()) {
			    LCD.clear();
			    wbPrint(String.valueOf(first * second), 1, 1);
			    Thread.sleep(500);
			    while (isNXTButton(ENTER, DOWN).isFalse())
				;

			    LCD.clear();

			    wbPrint(lastScreen, 1, 1);
			    Thread.sleep(500);
			}

		    }
		    break;

		case 4: // Division
		    LCD.clear();
		    while (currentSymbol == 4) {

			if ((wbRead(PORT_A) / 100 < 10 && first > 9)
				|| (wbRead(PORT_A) / 100 > -1 && first < 0)
				|| (wbRead(PORT_B) / 100 < 10 && second > 9)
				|| (wbRead(PORT_B) / 100 > -1 && second < 0)) {
			    LCD.clear();
			}
			first = (int) wbRead(PORT_A) / 100;
			second = (int) wbRead(PORT_B) / 100;

			if (!lastScreen.equals(first + " / " + second))
			    wbPrint(first + " / " + second, 1, 1);

			lastScreen = first + " / " + second;

			if (isNXTButton(ENTER, DOWN).isTrue()) {
			    LCD.clear();
			    wbPrint(String.valueOf(first / second), 1, 1);
			    Thread.sleep(500);
			    while (isNXTButton(ENTER, DOWN).isFalse())
				;

			    LCD.clear();

			    wbPrint(lastScreen, 1, 1);
			    Thread.sleep(500);
			}

		    }
		    break;

		case 5: // Absolute Value
		    LCD.clear();

		    while (currentSymbol == 5) {

			if ((wbRead(PORT_A) / 100 < 10 && first > 9)
				|| (wbRead(PORT_A) / 100 > -1 && first < 0)
				|| (wbRead(PORT_B) / 100 < 10 && second > 9)
				|| (wbRead(PORT_B) / 100 > -1 && second < 0)) {
			    LCD.clear();
			}

			first = (int) wbRead(PORT_A) / 100;

			// Only need one
			// input

			if (!lastScreen.equals("| " + first + " |"))
			    wbPrint("| " + first + " |", 1, 1);

			lastScreen = "| " + first + " |";

			if (isNXTButton(ENTER, DOWN).isTrue()) {
			    LCD.clear();
			    wbPrint(String.valueOf(Math.abs(first)), 1, 1); // Print
									    // result
			    Thread.sleep(500);
			    while (isNXTButton(ENTER, DOWN).isFalse())
				;

			    LCD.clear();

			    wbPrint(lastScreen, 1, 1);
			    Thread.sleep(500);
			}

		    }
		    break;

		case 6: // Power
		    LCD.clear();
		    while (currentSymbol == 6) {

			if ((wbRead(PORT_A) / 100 < 10 && first > 9)
				|| (wbRead(PORT_A) / 100 > -1 && first < 0)
				|| (wbRead(PORT_B) / 100 < 10 && second > 9)
				|| (wbRead(PORT_B) / 100 > -1 && second < 0)) {
			    LCD.clear();
			}
			first = (int) wbRead(PORT_A) / 100;
			second = (int) wbRead(PORT_B) / 100;
			if (!lastScreen.equals(first + " ^ " + second))
			    wbPrint(first + " ^ " + second, 1, 1);

			lastScreen = first + " ^ " + second;

			if (isNXTButton(ENTER, DOWN).isTrue()) {
			    LCD.clear();
			    wbPrint(String.valueOf(Math.pow(first, second)), 1,
				    1); // Print
					// result
			    Thread.sleep(500);
			    while (isNXTButton(ENTER, DOWN).isFalse())
				;

			    LCD.clear();

			    wbPrint(lastScreen, 1, 1);
			    Thread.sleep(500);
			}

		    }
		    break;

		case 7: // Nth Root
		    LCD.clear();
		    String suffix; // The suffix of first value (eg. th, st, or
				   // nd)
		    String fstring; // String of first value

		    while (currentSymbol == 7) {

			if ((wbRead(PORT_A) / 100 < 10 && first > 9)
				|| (wbRead(PORT_A) / 100 > -1 && first < 0)
				|| (wbRead(PORT_B) / 100 < 10 && second > 9)
				|| (wbRead(PORT_B) / 100 > -1 && second < 0)) {
			    LCD.clear();
			}

			first = (int) wbRead(PORT_A) / 100;
			second = (int) wbRead(PORT_B) / 100;

			fstring = String.valueOf(first);

			if (fstring.charAt(fstring.length() - 1) == '1') // Calculate
									 // appropriate
									 // suffix
			    suffix = "st"; // For 1st, 21st etc.
			else if (fstring.charAt(fstring.length() - 1) == '2')
			    suffix = "nd"; // 2nd, 22nd etc.
			else if (fstring.charAt(fstring.length() - 1) == '3')
			    suffix = "rd"; // 3rd, 23rd etc.
			else
			    suffix = "th"; // Everything else

			if (!lastScreen.equals(first + suffix + " root of "
				+ second))
			    wbPrint(first + suffix + " root of " + second, 1, 1);

			lastScreen = first + suffix + " root of " + second;

			if (isNXTButton(ENTER, DOWN).isTrue()) {
			    LCD.clear();
			    wbPrint(String.valueOf(nthroot(first, second)), 1,
				    1);

			    Thread.sleep(500);
			    while (isNXTButton(ENTER, DOWN).isFalse())
				;

			    LCD.clear();

			    wbPrint(lastScreen, 1, 1);
			    Thread.sleep(500);

			}

		    }
		    break;
		case 8: // Decimal to binary
		    LCD.clear();
		    while (currentSymbol == 8) {

			if ((wbRead(PORT_A) / 100 < 10 && first > 9)
				|| (wbRead(PORT_A) / 100 > -1 && first < 0)
				|| (wbRead(PORT_B) / 100 < 10 && second > 9)
				|| (wbRead(PORT_B) / 100 > -1 && second < 0)) {
			    LCD.clear();
			}
			first = (int) wbRead(PORT_A) / 100;
			second = (int) wbRead(PORT_B) / 100;
			if (!lastScreen.equals(String.valueOf(first)))
			    wbPrint(first, 1, 1);

			lastScreen = String.valueOf(first);

			if (isNXTButton(ENTER, DOWN).isTrue()) {
			    LCD.clear();
			    wbPrint(Integer.toBinaryString(first), 1, 1); // Print
									  // result
			    Thread.sleep(500);
			    while (isNXTButton(ENTER, DOWN).isFalse())
				;

			    LCD.clear();

			    wbPrint(lastScreen, 1, 1);
			    Thread.sleep(500);
			}

		    }
		    break;
		case 9: // Decimal to hex
		    LCD.clear();
		    while (currentSymbol == 9) {

			if ((wbRead(PORT_A) / 100 < 10 && first > 9)
				|| (wbRead(PORT_A) / 100 > -1 && first < 0)
				|| (wbRead(PORT_B) / 100 < 10 && second > 9)
				|| (wbRead(PORT_B) / 100 > -1 && second < 0)) {
			    LCD.clear();
			}
			first = (int) wbRead(PORT_A) / 100;
			second = (int) wbRead(PORT_B) / 100;

			if (!lastScreen.equals(String.valueOf(first)))
			    wbPrint(first, 1, 1);

			lastScreen = String.valueOf(first);

			if (isNXTButton(ENTER, DOWN).isTrue()) {
			    LCD.clear();
			    wbPrint(Integer.toHexString(first), 1, 1); // Print
								       // result
			    Thread.sleep(500);
			    while (isNXTButton(ENTER, DOWN).isFalse())
				;

			    LCD.clear();

			    wbPrint(lastScreen, 1, 1);
			    Thread.sleep(500);
			}

		    }
		    break;
		case 10: // Tangents
		    LCD.clear();
		    while (currentSymbol == 10) {

			if ((wbRead(PORT_A) / 100 < 10 && first > 9)
				|| (wbRead(PORT_A) / 100 > -1 && first < 0)
				|| (wbRead(PORT_B) / 100 < 10 && second > 9)
				|| (wbRead(PORT_B) / 100 > -1 && second < 0)) {
			    LCD.clear();
			}
			first = (int) wbRead(PORT_A) / 100;
			second = (int) wbRead(PORT_B) / 100;

			if (!lastScreen.equals("tan(" + first + ")"))
			    wbPrint("tan(" + first + ")", 1, 1);

			lastScreen = "tan(" + first + ")";

			if (isNXTButton(ENTER, DOWN).isTrue()) {
			    LCD.clear();
			    wbPrint(Math.tan(first), 1, 1); // Print result

			    Thread.sleep(500);
			    while (isNXTButton(ENTER, DOWN).isFalse())
				;

			    LCD.clear();

			    wbPrint(lastScreen, 1, 1);
			    Thread.sleep(500);
			}

		    }
		    break;
		case 11: // Sines
		    LCD.clear();
		    while (currentSymbol == 11) {

			if ((wbRead(PORT_A) / 100 < 10 && first > 9)
				|| (wbRead(PORT_A) / 100 > -1 && first < 0)
				|| (wbRead(PORT_B) / 100 < 10 && second > 9)
				|| (wbRead(PORT_B) / 100 > -1 && second < 0)) {
			    LCD.clear();
			}
			first = (int) wbRead(PORT_A) / 100;
			second = (int) wbRead(PORT_B) / 100;

			if (!lastScreen.equals("sin(" + first + ")"))
			    wbPrint("sin(" + first + ")", 1, 1);

			lastScreen = "sin(" + first + ")";

			if (isNXTButton(ENTER, DOWN).isTrue()) {
			    LCD.clear();
			    wbPrint(Math.sin(first), 1, 1); // Print result

			    Thread.sleep(500);
			    while (isNXTButton(ENTER, DOWN).isFalse())
				;

			    LCD.clear();

			    wbPrint(lastScreen, 1, 1);
			    Thread.sleep(500);
			}

		    }
		    break;
		case 12: // Cosines
		    LCD.clear();
		    while (currentSymbol == 12) {

			if ((wbRead(PORT_A) / 100 < 10 && first > 9)
				|| (wbRead(PORT_A) / 100 > -1 && first < 0)
				|| (wbRead(PORT_B) / 100 < 10 && second > 9)
				|| (wbRead(PORT_B) / 100 > -1 && second < 0)) {
			    LCD.clear();
			}
			first = (int) wbRead(PORT_A) / 100;
			second = (int) wbRead(PORT_B) / 100;

			if (!lastScreen.equals("cos(" + first + ")"))
			    wbPrint("cos(" + first + ")", 1, 1);

			lastScreen = "cos(" + first + ")";

			if (isNXTButton(ENTER, DOWN).isTrue()) {
			    LCD.clear();
			    wbPrint(Math.cos(first), 1, 1); // Print result

			    Thread.sleep(500);
			    while (isNXTButton(ENTER, DOWN).isFalse())
				;

			    LCD.clear();

			    wbPrint(lastScreen, 1, 1);
			    Thread.sleep(500);
			}

		    }
		    break;
		    
		case 13: // Secant
		    LCD.clear();
		    while (currentSymbol == 13) {

			if ((wbRead(PORT_A) / 100 < 10 && first > 9)
				|| (wbRead(PORT_A) / 100 > -1 && first < 0)
				|| (wbRead(PORT_B) / 100 < 10 && second > 9)
				|| (wbRead(PORT_B) / 100 > -1 && second < 0)) {
			    LCD.clear();
			}
			first = (int) wbRead(PORT_A) / 100;
			second = (int) wbRead(PORT_B) / 100;

			if (!lastScreen.equals("sec(" + first + ")"))
			    wbPrint("sec(" + first + ")", 1, 1);

			lastScreen = "sec(" + first + ")";

			if (isNXTButton(ENTER, DOWN).isTrue()) {
			    LCD.clear();
			    wbPrint(secant(first), 1, 1); // Print result

			    Thread.sleep(500);
			    while (isNXTButton(ENTER, DOWN).isFalse())
				;

			    LCD.clear();

			    wbPrint(lastScreen, 1, 1);
			    Thread.sleep(500);
			}

		    }
		    break;
		    
		case 14: // Cosecant
		    LCD.clear();
		    while (currentSymbol == 14) {

			if ((wbRead(PORT_A) / 100 < 10 && first > 9)
				|| (wbRead(PORT_A) / 100 > -1 && first < 0)
				|| (wbRead(PORT_B) / 100 < 10 && second > 9)
				|| (wbRead(PORT_B) / 100 > -1 && second < 0)) {
			    LCD.clear();
			}
			first = (int) wbRead(PORT_A) / 100;
			second = (int) wbRead(PORT_B) / 100;

			if (!lastScreen.equals("csc(" + first + ")"))
			    wbPrint("csc(" + first + ")", 1, 1);

			lastScreen = "csc(" + first + ")";

			if (isNXTButton(ENTER, DOWN).isTrue()) {
			    LCD.clear();
			    wbPrint(cosecant(first), 1, 1); // Print result

			    Thread.sleep(500);
			    while (isNXTButton(ENTER, DOWN).isFalse())
				;

			    LCD.clear();

			    wbPrint(lastScreen, 1, 1);
			    Thread.sleep(500);
			}

		    }
		    break;
		    
		case 15: // Cotangent
		    LCD.clear();
		    while (currentSymbol == 15) {

			if ((wbRead(PORT_A) / 100 < 10 && first > 9)
				|| (wbRead(PORT_A) / 100 > -1 && first < 0)
				|| (wbRead(PORT_B) / 100 < 10 && second > 9)
				|| (wbRead(PORT_B) / 100 > -1 && second < 0)) {
			    LCD.clear();
			}
			first = (int) wbRead(PORT_A) / 100;
			second = (int) wbRead(PORT_B) / 100;

			if (!lastScreen.equals("cot(" + first + ")"))
			    wbPrint("cot(" + first + ")", 1, 1);

			lastScreen = "cot(" + first + ")";

			if (isNXTButton(ENTER, DOWN).isTrue()) {
			    LCD.clear();
			    wbPrint(cotangent(first), 1, 1); // Print result

			    Thread.sleep(500);
			    while (isNXTButton(ENTER, DOWN).isFalse())
				;

			    LCD.clear();

			    wbPrint(lastScreen, 1, 1);
			    Thread.sleep(500);
			}

		    }
		    break;


		}

	    }

	} catch (Exception e) {
	}

    }
}
