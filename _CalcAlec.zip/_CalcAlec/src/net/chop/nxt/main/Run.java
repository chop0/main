/**
 * 
 */
package net.chop.nxt.main;

import wzb.Program;

/**
 * @author Alec Petridis
 *         <p>
 *         Runs the specified program, in this case a calculator
 *         </p>
 */
public class Run {

    public static void main(String[] args) {
	Program.execute(new Calculator());
    }
}
